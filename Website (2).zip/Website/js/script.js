// JavaScript in your main page
document.addEventListener("DOMContentLoaded", function() {
    // Initialize the ticket count from local storage
    const ticketCount = document.getElementById("ticket-count");
    const ticketContent = JSON.parse(localStorage.getItem("ticketContent")) || [];
    ticketCount.textContent = ticketContent.length.toString();
});

document.getElementById("ticket-button").addEventListener("click", function() {
    // Show the modal
    const modal = document.getElementById("ticket-modal");
    modal.style.display = "block";

    // Retrieve and display the ticket content
    const ticketContent = JSON.parse(localStorage.getItem("ticketContent")) || [];
    const ticketList = document.getElementById("ticket-content");
    ticketList.innerHTML = ""; // Clear previous content

    ticketContent.forEach((item, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = item.serviceName + " - " + item.serviceDescription;

        const removeButton = document.createElement("button");
        removeButton.textContent = "X";
        removeButton.onclick = () => removeTicketItem(index); // Define the click event

        listItem.appendChild(removeButton);
        ticketList.appendChild(listItem);
    });
});

document.getElementById("close-ticket").addEventListener("click", function() {
    // Close the modal
    const modal = document.getElementById("ticket-modal");
    modal.style.display = "none";
});

// Function to add a service to the ticket
function addToTicket(serviceName, serviceDescription) {
    // Update the count
    const ticketCount = document.getElementById("ticket-count");
    const currentCount = parseInt(ticketCount.textContent, 10);
    ticketCount.textContent = (currentCount + 1).toString();

    // Store content in local storage
    const ticketContent = JSON.parse(localStorage.getItem("ticketContent")) || [];
    ticketContent.push({ serviceName, serviceDescription });
    localStorage.setItem("ticketContent", JSON.stringify(ticketContent));
}

// Function to remove a specific item from the ticket
function removeTicketItem(index) {
    const ticketContent = JSON.parse(localStorage.getItem("ticketContent")) || [];
    if (index >= 0 && index < ticketContent.length) {
        ticketContent.splice(index, 1);
        localStorage.setItem("ticketContent", JSON.stringify(ticketContent));
    }

    // Refresh the displayed content
    const ticketList = document.getElementById("ticket-content");
    ticketList.innerHTML = "";

    ticketContent.forEach((item, newIndex) => {
        const listItem = document.createElement("li");
        listItem.textContent = item.serviceName + " - " + item.serviceDescription;

        const removeButton = document.createElement("button");
        removeButton.textContent = "X";
        removeButton.onclick = () => removeTicketItem(newIndex); // Define the click event

        listItem.appendChild(removeButton);
        ticketList.appendChild(listItem);
    });

    // Update the ticket count
    const ticketCount = document.getElementById("ticket-count");
    ticketCount.textContent = ticketContent.length.toString();
}
