function bookAllTickets() {
    // ... (booking logic)

    // After booking, send a confirmation email to the user
    const userEmail = 'tlhalemap19.com'; // Replace with the user's email
    sendConfirmationEmail(userEmail);
}

function sendConfirmationEmail(userEmail) {
    // Send an AJAX request to the PHP script
    $.ajax({
        type: 'POST',
        url: 'connection/mail.php', // Replace with the actual path to your PHP script
        data: { recipientEmail: userEmail },
        success: function (response) {
            if (response === 'success') {
                alert('Booking confirmation email sent successfully.');
            } else {
                alert('Failed to send the email. Please contact support.');
            }
        }
    });
}
